<div class="container pt-5">
    <div class="row justify-content-center">
        <div class="col-4">
          <div class="card">
            <div class="card-header">
            <center>
                <b>Login Siswa</b>
                </center>
                <center><img src="image/skin.png" alt=""></center>
               </div>
               <div class="card-body">
                <form action="index.php?aksi=loginsiswa" method="post">
                    <div class="form-group">
                        <input type="text" name= "nisn" placeholder=Nisn  class="form-contol">
                    </div>
                    <div class="form-group">
                        <input type="text" name= "nis" placeholder=Nis class="form-contol">
                    </div>
                    <button name="login" class="btn btn-primary" id="loginB">Login</button>
                </form>
             </div>
          </div>
        </div>
    </div>
</div>